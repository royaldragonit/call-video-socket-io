import * as express from 'express';
import * as socketIo from 'socket.io'; // new
import { createServer, Server } from 'http'; //new

export class ChatServer {
    private socketsArray = [];
    public static readonly PORT: number = 5000;
    private app: express.Application;
    private port: string | number;
    private server: Server; // new
    public io;
    constructor() {
        this.createApp();
        this.config();
        this.createServer();
        this.sockets(); // new 
        this.listen();
    }
    private sockets(): void {
        this.io = socketIo(this.server);
    }
    private config(): void {
        this.port = process.env.PORT || ChatServer.PORT;
    }

    private listen(): void {
        this.server.listen(this.port, () => {
            console.log('Running server on port %s', this.port);
        });
        this.io.on('connection', (socket) => {
            socket.broadcast.emit('add-users', {
                users: [socket.id]
            });

            socket.on('disconnect', () => {
                this.socketsArray.splice(this.socketsArray.indexOf(socket.id), 1);
                this.io.emit('remove-user', socket.id);
            });
            socket.on('make-offer', function (data) {
                socket.to(data.to).emit('offer-made', {
                    offer: data.offer,
                    socket: socket.id
                });
            });
        });
    }

    // new
    private createServer(): void {
        this.server = createServer(this.app);
    }

    public getApp(): express.Application {
        return this.app;
    }
    private createApp(): void {
        this.app = express();
        this.app.use(express.static('public'));
    }
}